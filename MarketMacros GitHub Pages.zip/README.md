# MarketMacros — Futures & Commodities Intelligence Terminal

AI-powered pre-market intelligence for futures and commodities day traders.

## Setup
1. Enable GitHub Pages: Settings → Pages → Source: Deploy from branch → main → / (root)
2. Open your Pages URL in Safari on iPhone
3. Enter your Anthropic API key (get one at console.anthropic.com)
4. Add to Home Screen via Share button
